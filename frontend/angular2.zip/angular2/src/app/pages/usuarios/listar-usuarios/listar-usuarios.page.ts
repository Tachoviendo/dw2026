import { Component } from '@angular/core';

import { Usuario } from "../../../model/usuario";

@Component({
  imports: [],
  selector: 'app-listar-usuarios',
  styleUrl: './listar-usuarios.page.css',
  templateUrl: './listar-usuarios.page.html',
})
export class ListarUsuariosPage {
  public usuarios: Usuario[] = [
    {
      id_usuario: 1,
      nombre: "Nacho",
      apellido: "nacho",
      username: "tachoviendo",
    },
  ];
}
