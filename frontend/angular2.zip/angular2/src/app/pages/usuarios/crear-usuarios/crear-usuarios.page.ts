import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-crear-usuarios',
  styleUrl: './crear-usuarios.page.css',
  templateUrl: './crear-usuarios.page.html',
})


export class CrearUsuarioPage{
  public nombre = 'nombreInicial';

}
export class CrearUsuariosPage {}
